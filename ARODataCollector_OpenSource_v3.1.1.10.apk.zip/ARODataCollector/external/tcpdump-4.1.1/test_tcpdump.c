#include<stdio.h>
#include<unistd.h>
#include"tcpdump.h"

int main(nt argc,char** argv) {
tcpDump_StartCapture(argc,argv);
return 0;
}
