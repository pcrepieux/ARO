#ifndef _SOCKET_SERVER_H_
#define _SOCKET_SERVER_H_

void * start_server_socket(void * arg);

void dostuff(int); /* function prototype */
void socket_server(const char *msg);

#endif
