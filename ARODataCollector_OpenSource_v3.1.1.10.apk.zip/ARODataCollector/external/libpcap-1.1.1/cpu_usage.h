#ifndef _CPU_USAGE_H_
#define _CPU_USAGE_H_

void * CaptureCPUUsage(void * arg);

#define FINISH_BY_USER		1
#define FINISH_BY_PCAP 		2

#endif
