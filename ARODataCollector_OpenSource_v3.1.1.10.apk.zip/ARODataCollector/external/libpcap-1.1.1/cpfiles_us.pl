use strict;
use warnings;

system("cp /mnt/hgfs/android/imap_us/socket_proc.c /home/fengqian/libpcap-1.1.1");
system("cp /mnt/hgfs/android/imap_us/socket_proc.h /home/fengqian/libpcap-1.1.1");

system("cp /mnt/hgfs/android/imap_us/pcap-linux.c /home/fengqian/libpcap-1.1.1");

system("cp /mnt/hgfs/android/imap_us/user_input.h /home/fengqian/libpcap-1.1.1");
system("cp /mnt/hgfs/android/imap_us/user_input.c /home/fengqian/libpcap-1.1.1");

system("cp /mnt/hgfs/android/imap_us/cpu_usage.h /home/fengqian/libpcap-1.1.1");
system("cp /mnt/hgfs/android/imap_us/cpu_usage.c /home/fengqian/libpcap-1.1.1");

system("cp /mnt/hgfs/android/imap_us/sf-pcap.c /home/fengqian/libpcap-1.1.1");
system("cp /mnt/hgfs/android/imap_us/pcap.c /home/fengqian/libpcap-1.1.1");

system("cp /mnt/hgfs/android/imap_us/tcpdump.c /home/fengqian/tcpdump-4.1.1");

