
#ifndef tcpdump_h
#define tcpdump_h

int tcpDump_StartCapture(int argc, char**argv);

#endif
