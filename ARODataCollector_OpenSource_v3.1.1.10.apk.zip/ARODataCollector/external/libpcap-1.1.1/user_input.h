#ifndef _USER_INPUT_H_
#define _USER_INPUT_H_

void * CaptureUserInput(void * arg);


#endif