char pcap_version[] = "1.1.1";
